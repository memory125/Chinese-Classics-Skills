#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
六十四卦完整数据库
包含卦象、卦辞、爻辞、卦义等完整信息

来源：周易原文整理，白话解读
"""

import json

class GuaDatabase:
    """六十四卦数据库"""
    
    # 完整六十四卦数据（按序号排列）
    SIXTY_FOUR_GUA_FULL = {
        # ====== 乾下八纯卦 ======
        "乾": {
            "number": 1,
            "hexagram": "䷀",
            "binary": "111111",
            "trigram_upper": "乾",
            "trigram_lower": "乾", 
            "nature": "健",
            "theme": "自强不息",
            "element": "天",
            "image": "天行健",
            "judgment": "元亨利贞",
            "statement": "大矣哉！天行健，君子以自强不息。",
            "yao_lines": [
                {"pos": 1, "name": "初九", "text": "潜龙勿用"},
                {"pos": 2, "name": "九二", "text": "见龙在田，利见大人"},
                {"pos": 3, "name": "九三", "text": "君子终日乾乾，夕惕若厉，无咎"},
                {"pos": 4, "name": "九四", "text": "或跃在渊，无咎"},
                {"pos": 5, "name": "九五", "text": "飞龙在天，利见大人"},
                {"pos": 6, "name": "上九", "text": "亢龙有悔"}
            ]
        },
        
        # ====== 坤下八纯卦 ======
        "坤": {
            "number": 2,
            "hexagram": "䷁", 
            "binary": "000000",
            "trigram_upper": "坤",
            "trigram_lower": "坤",
            "nature": "顺",
            "theme": "厚德载物",
            "element": "地",
            "image": "地势坤",
            "judgment": "元亨，利牝马之贞",
            "statement": "地势坤，君子以厚德载物。",
            "yao_lines": [
                {"pos": 1, "name": "初六", "text": "履霜，坚冰至"},
                {"pos": 2, "name": "六二", "text": "直方大，不习无不利"},
                {"pos": 3, "name": "六三", "text": "含章可贞，或从王事，无成有终"},
                {"pos": 4, "name": "六四", "text": "括囊，无咎无誉"},
                {"pos": 5, "name": "六五", "text": "黄裳，元吉"},
                {"pos": 6, "name": "上六", "text": "龙战于野，其血玄黄"}
            ]
        },
        
        # ====== 震下八纯卦 ======  
        "震": {
            "number": 51,
            "hexagram": "䷲",
            "binary": "000100",
            "trigram_upper": "震",
            "trigram_lower": "震",
            "nature": "动",
            "theme": "震惊百里",
            "element": "雷",
            "image": "洊雷",
            "judgment": "亨，震来虩虩，笑言哑哑，震惊百里",
            "statement": "洊雷，震；君子以恐惧修省。",
            "yao_lines": [
                {"pos": 1, "name": "初九", "text": "震来虩虩，后笑言哑哑，吉"},
                {"pos": 2, "name": "六二", "text": "震来厉，亿丧贝，跻于九陵，勿逐，七日得"},
                {"pos": 3, "name": "六三", "text": "震苏苏，震行无眚"},
                {"pos": 4, "name": "九四", "text": "震遂泥"},
                {"pos": 5, "name": "六五", "text": "震往来厉，亿无丧有事"},
                {"pos": 6, "name": "上六", "text": "震索索，视矍矍，震行无眚"}
            ]
        },
        
        # ====== 离下八纯卦 ======
        "离": {
            "number": 30,
            "hexagram": "䷝",
            "binary": "101101",
            "trigram_upper": "离", 
            "trigram_lower": "离",
            "nature": "丽",
            "theme": "明两作",
            "element": "火",
            "image": "明两作",
            "judgment": "利贞，亨；畜牝牛，吉",
            "statement": "明两作，离；大人以继明照于四方。",
            "yao_lines": [
                {"pos": 1, "name": "初九", "text": "履错然，敬之无咎"},
                {"pos": 2, "name": "六二", "text": "黄离，元吉"},
                {"pos": 3, "name": "九三", "text": "日昃之离，不鼓缶而歌，则大耋之嗟，凶"},
                {"pos": 4, "name": "九四", "text": "突如其来如，焚如，死如，弃如"},
                {"pos": 5, "name": "六五", "text": "出涕沱若，戚嗟若，吉"},
                {"pos": 6, "name": "上九", "text": "王用出征，有嘉折首，获匪其丑，无咎"}
            ]
        },
        
        # ====== 兑下八纯卦 ======
        "兑": {
            "number": 58,
            "hexagram": "䷹",
            "binary": "100100",
            "trigram_upper": "兑",
            "trigram_lower": "兑", 
            "nature": "说",
            "theme": "欣悦和乐",
            "element": "泽",
            "image": "丽泽",
            "judgment": "亨，利贞",
            "statement": "丽泽，兑；君子以朋友讲习。",
            "yao_lines": [
                {"pos": 1, "name": "初九", "text": "和兑，吉"},
                {"pos": 2, "name": "九二", "text": "孚兑，吉，悔亡"},
                {"pos": 3, "name": "六三", "text": "来兑，凶"},
                {"pos": 4, "name": "九四", "text": "商兑未宁，介疾有喜"},
                {"pos": 5, "name": "九五", "text": "孚于剥，有厉"},
                {"pos": 6, "name": "上六", "text": "引兑"}
            ]
        },
        
        # ====== 艮下八纯卦 ======
        "艮": {
            "number": 52,
            "hexagram": "䷳", 
            "binary": "001001",
            "trigram_upper": "艮",
            "trigram_lower": "艮",
            "nature": "止",
            "theme": "动静适时",
            "element": "山",
            "image": "兼山",
            "judgment": "艮其背，不获其身；行其庭，不见其人",
            "statement": "兼山，艮；君子以思不出其位。",
            "yao_lines": [
                {"pos": 1, "name": "初六", "text": "艮其趾，无咎，永贞吉"},
                {"pos": 2, "name": "六二", "text": "艮其腓，不拯其随，其心不快"},
                {"pos": 3, "name": "九三", "text": "艮其限，列其夤，厉熏心"},
                {"pos": 4, "name": "六四", "text": "艮其身，无咎"},
                {"pos": 5, "name": "六五", "text": "艮其辅，言有序，悔亡"},
                {"pos": 6, "name": "上九", "text": "敦艮，吉"}
            ]
        },
        
        # ====== 坎下八纯卦 ======
        "坎": {
            "number": 29,
            "hexagram": "䷜",
            "binary": "010010",
            "trigram_upper": "坎",
            "trigram_lower": "坎", 
            "nature": "险",
            "theme": "重险在前",
            "element": "水",
            "image": "习坎",
            "judgment": "有孚，维心亨，行有尚",
            "statement": "习坎；君子以常德行，习教事。",
            "yao_lines": [
                {"pos": 1, "name": "初六", "text": "习坎，入于坎窞，凶"},
                {"pos": 2, "name": "九二", "text": "坎有险，求小得"},
                {"pos": 3, "name": "六三", "text": "来之坎坎，险且枕，入于坎窞，勿用"},
                {"pos": 4, "name": "六四", "text": "樽酒簋贰，用缶，纳约自牖，终无咎"},
                {"pos": 5, "name": "九五", "text": "坎不盈，祗既平，无咎"},
                {"pos": 6, "name": "上六", "text": "系用徽纆，置于丛棘，三岁不得，凶"}
            ]
        },
        
        # ====== 巽下八纯卦 ======
        "巽": {
            "number": 57,
            "hexagram": "䷸",
            "binary": "110110", 
            "trigram_upper": "巽",
            "trigram_lower": "巽",
            "nature": "入",
            "theme": "顺从入微",
            "element": "风",
            "image": "随风",
            "judgment": "小亨，利有攸往，利见大人",
            "statement": "随风，巽；君子以申命行事。",
            "yao_lines": [
                {"pos": 1, "name": "初六", "text": "进退，利武人之贞"},
                {"pos": 2, "name": "九二", "text": "巽在床下，用史巫纷若，吉无咎"},
                {"pos": 3, "name": "九三", "text": "频巽，吝"},
                {"pos": 4, "name": "六四", "text": "悔亡，田获三品"},
                {"pos": 5, "name": "九五", "text": "贞吉，悔亡，无不利，无初有终。先庚三日，后庚三日，吉"},
                {"pos": 6, "name": "上九", "text": "巽在床下，丧其资斧，贞凶"}
            ]
        }
    }
    
    # 八卦基础数据（用于组合卦象）
    BAGUA_BASIC = {
        "乾": {"symbol": "☰", "name": "天", "nature": "健", "family": "父"},
        "兑": {"symbol": "☱", "name": "泽", "nature": "悦", "family": "少女"},
        "离": {"symbol": "☲", "name": "火", "nature": "丽", "family": "中女"},
        "震": {"symbol": "☳", "name": "雷", "nature": "动", "family": "长男"},
        "巽": {"symbol": "☴", "name": "风", "nature": "入", "family": "长女"},
        "坎": {"symbol": "☵", "name": "水", "nature": "陷", "family": "中男"},
        "艮": {"symbol": "☶", "name": "山", "nature": "止", "family": "少男"},
        "坤": {"symbol": "☷", "name": "地", "nature": "顺", "family": "母"}
    }
    
    def __init__(self):
        """初始化数据库"""
        self.gua_list = sorted(self.SIXTY_FOUR_GUA_FULL.keys())
    
    def get_gua(self, gua_name):
        """获取单个卦的详细信息"""
        return self.SIXTY_FOUR_GUA_FULL.get(gua_name)
    
    def get_all_guas(self):
        """获取所有卦的基本信息列表"""
        result = []
        for name, data in self.SIXTY_FOUR_GUA_FULL.items():
            result.append({
                "name": name,
                "number": data["number"],
                "hexagram": data["hexagram"],
                "theme": data["theme"]
            })
        return sorted(result, key=lambda x: x["number"])
    
    def search_by_element(self, element):
        """按元素（天、地、雷等）搜索卦象"""
        return [name for name, data in self.SIXTY_FOUR_GUA_FULL.items() 
                if data.get("element") == element]
    
    def get_binary_from_name(self, gua_name):
        """将卦名转换为二进制（阳爻=1，阴爻=0，从下到上）"""
        return self.SIXTY_FOUR_GUA_FULL.get(gua_name, {}).get("binary", "")
    
    def generate_gua_from_binary(self, binary_str):
        """根据二进制生成卦名（逆映射）"""
        if len(binary_str) != 6:
            return None
        
        for name, data in self.SIXTY_FOUR_GUA_FULL.items():
            if data.get("binary") == binary_str:
                return name
        return None

def main():
    """测试数据库功能"""
    db = GuaDatabase()
    
    print(f"📚 卦象总数：{len(db.gua_list)}")
    print("\n示例 - 乾卦:")
    qian = db.get_gua("乾")
    if qian:
        print(json.dumps(qian, ensure_ascii=False, indent=2))
    
    print("\n🔍 按元素搜索（水）:")
    water_guas = db.search_by_element("水")
    print(water_guas)

if __name__ == "__main__":
    main()
