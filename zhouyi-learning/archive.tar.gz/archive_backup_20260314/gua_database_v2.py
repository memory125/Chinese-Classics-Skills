#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
六十四卦数据库 v2 - 扩展版
包含 24 个常用卦象完整数据 + 二进制映射
"""

GUA_DATABASE_FULL = {
    # == 八纯卦（基础八卦）==
    "111111": {"name": "乾", "hexagram": "䷀", "nature": "健", "theme": "自强不息", "element": "天"},
    "000000": {"name": "坤", "hexagram": "䷁", "nature": "顺", "theme": "厚德载物", "element": "地"},
    "100100": {"name": "兑", "hexagram": "䷹", "nature": "悦", "theme": "欣悦和乐", "element": "泽"},
    "101101": {"name": "离", "hexagram": "䷝", "nature": "丽", "theme": "明两作", "element": "火"},
    "010010": {"name": "坎", "hexagram": "䷜", "nature": "陷", "theme": "重险在前", "element": "水"},
    "001001": {"name": "艮", "hexagram": "䷳", "nature": "止", "theme": "动静适时", "element": "山"},
    "000100": {"name": "震", "hexagram": "䷲", "nature": "动", "theme": "震惊百里", "element": "雷"},
    "110110": {"name": "巽", "hexagram": "䷸", "nature": "入", "theme": "顺从入微", "element": "风"},
    
    # == 重要常用卦（天地交泰）==
    "111000": {"name": "泰", "hexagram": "䷊", "nature": "通", "theme": "天地交泰，诸事顺利", "element": "地天"},
    "000111": {"name": "否", "hexagram": "䷋", "nature": "塞", "theme": "天地不交，闭塞不通", "element": "天地"},
    
    # == 重要常用卦（水雷/山水）==
    "010001": {"name": "屯", "hexagram": "䷂", "nature": "难", "theme": "万物始生之艰难", "element": "水雷"},
    "100010": {"name": "蒙", "hexagram": "䷃", "nature": "昧", "theme": "启蒙求知，幼稚待教", "element": "山水"},
    
    # == 风火/水火 ==
    "110100": {"name": "家人", "hexagram": "䷤", "nature": "亲", "theme": "家道正，内无怨女", "element": "风火"},
    "010111": {"name": "既济", "hexagram": "䷾", "nature": "成", "theme": "事已成，初吉终乱", "element": "水火"},
    
    # == 火水/雷风 ==
    "111010": {"name": "未济", "hexagram": "䷿", "nature": "乱", "theme": "事未成，慎辨物居方", "element": "火水"},
    "001001": {"name": "恒", "hexagram": "䷟", "nature": "久", "theme": "长久之道，不易之理", "element": "雷风"},
    
    # == 山天/天山 ==
    "001111": {"name": "大畜", "hexagram": "䷙", "nature": "止", "theme": "大为蓄积，厚积薄发", "element": "山天"},
    "111001": {"name": "遁", "hexagram": "䷠", "nature": "退", "theme": "退避待时，隐居修德", "element": "天山"},
    
    # == 地雷/雷地 ==
    "000111": {"name": "复", "hexagram": "䷗", "nature": "返", "theme": "一阳来复，万物更新", "element": "地雷"},
    "110001": {"name": "豫", "hexagram": "䷏", "nature": "乐", "theme": "顺时而动，愉悦和乐", "element": "雷地"},
    
    # == 泽天/天泽 ==
    "100111": {"name": "夬", "hexagram": "䷪", "nature": "决", "theme": "果决去除，刚决柔", "element": "泽天"},
    "111100": {"name": "履", "hexagram": "䷉", "nature": "礼", "theme": "如履薄冰，小心行事", "element": "天泽"},
    
    # == 地风/风地 ==
    "000011": {"name": "升", "hexagram": "䷭", "nature": "进", "theme": "积小成大，柔顺上升", "element": "地风"},
    "110000": {"name": "观", "hexagram": "䷓", "nature": "视", "theme": "以大观小，示人楷模", "element": "风地"},
    
    # == 水山/山水（重复）==
    "010001": {"name": "蹇", "hexagram": "䷦", "nature": "难", "theme": "见险而止，反身修德", "element": "水山"},
    
    # == 雷水解困 ==
    "001010": {"name": "解", "hexagram": "䷧", "nature": "散", "theme": "解难释困，险以动", "element": "雷水"},
}

# 名称到二进制的反向映射
GUA_NAME_TO_BINARY = {v["name"]: k for k, v in GUA_DATABASE_FULL.items()}

def get_gua_by_binary(binary):
    """根据二进制获取卦象信息"""
    return GUA_DATABASE_FULL.get(binary, {"name": "待查询", "hexagram": "?", "theme": "?"})

def get_gua_by_name(name):
    """根据卦名获取卦象信息"""
    binary = GUA_NAME_TO_BINARY.get(name)
    if binary:
        return GUA_DATABASE_FULL[binary]
    return None

if __name__ == "__main__":
    print(f"✅ 卦象数据库已加载，共 {len(GUA_DATABASE_FULL)} 个常用卦")
    print("\n示例查询：")
    print("乾卦:", get_gua_by_name("乾"))
    print("二进制 111000:", get_gua_by_binary("111000"))

# 补充缺失的常用卦（扩展版）
GUA_DATABASE_FULL.update({
    "001110": {"name": "小过", "hexagram": "䷽", "nature": "过", "theme": "小有过度，行止得中", "element": "雷山"},
    "101000": {"name": "咸", "hexagram": "䷞", "nature": "感", "theme": "无心之感，感应相通", "element": "泽山"},
    "111110": {"name": "夬", "hexagram": "䷪", "nature": "决", "theme": "果决去除，刚决柔也", "element": "泽天"},
    "011111": {"name": "姤", "hexagram": "䷫", "nature": "遇", "theme": "阴阳相遇，勿取女", "element": "天风"},
    "110000": {"name": "观", "hexagram": "䷓", "nature": "视", "theme": "以大观小，示人楷模", "element": "风地"},
    "000111": {"name": "遁", "hexagram": "䷠", "nature": "退", "theme": "退避待时，隐居修德", "element": "天山"},
    "100011": {"name": "大壮", "hexagram": "䷡", "nature": "盛", "theme": "刚健有力，正大光明", "element": "雷天"},
    "001111": {"name": "晋", "hexagram": "䷢", "nature": "进", "theme": "旭日东升，前进无疆", "element": "火地"},
})

print(f"更新后共 {len(GUA_DATABASE_FULL)} 个卦象")
